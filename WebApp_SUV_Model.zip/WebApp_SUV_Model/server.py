from flask import Flask,request,render_template
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("SUV_Purchase.csv")
app= Flask(__name__)

#deserialize
model = pickle.load(open('model.pkl','rb'))

@app.route('/')
def index():
    return render_template("index.html")  # with this we are able to send our webpage to the client(into browser)

@app.route('/predict',methods=['POST','GET'])  #gets input data from client(brrowser) to Flask server - to give it to ML model
def predict():
    features = [int(x) for x in request.form.values()]
    print(features)
    final= [np.array(features)]
    x=df.iloc[:, 2:4].values

    #our model was trained on normalized(scaled) data
    sst=StandardScaler().fit(x)
    output = model.predict(sst.transform(final))
    print(output)

    if output[0]==0:
        return render_template('index.html',pred=f'NO! The person WILL NOT be able to purchase the SUV')
    else:
        return render_template('index.html',pred=f'YES!The person WILL be able to purchase the SUV')

if __name__ == '__main__':
    app.run(debug=True)